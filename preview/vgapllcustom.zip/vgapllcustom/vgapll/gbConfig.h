#ifndef _GB_CONFIG_H
 #define _GB_CONFIG_H
 
 #define use_lib_tinybitluni_fast

 //Video colors (8 colores es DAC 3 bits) TTGO VGA32 and Wemos D1 R32
 #define use_lib_vga8colors

 //Video mode
 #define use_lib_320x200

 //View logs serial
 #define use_lib_log_serial
 



 #define gb_add_offset_x 60 
 #define gb_add_offset_y 40
 #define gb_topeX 320
 #define gb_topeY 200
 #define gb_topeX_div4 80  
 
 
#endif
