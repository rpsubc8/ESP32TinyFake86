#ifndef _CHIP8_H
 #define _CHIP8_H

 #include "hardware.h"
 //#include "MartianVGA.h"

 // Declared vars
 //extern VGA3Bit vga;

 // Declared methods
#endif
